// Cameron Schwartzberg
// 2/18/2024, 7:37 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#include "Movement.h"
#include "Setup.h"
#include "PinDefinitions.h"
#include <Servo.h>

// Rumble motor movement, will write to the motor, 180 for forward, 0 for backward, 90 for stop
// We might not need both of these functions, but we'll test with both
void rumbleMovement::rumbleMotorForward(){
    motor.write(180);
}

void rumbleMovement::rumbleMotorBackward(){
    motor.write(0);
}

void rumbleMovement::rumbleMotorStop(){
    motor.write(90);
}


// Dig motor movement, will write to the motor, "180" for forward, "0" for backward, "90" for stop
// Actuator movement, will ...
// Actuator movement, not yet implemented
void digMovement::digMotorForward(){
    motor.write(180);
}

void digMovement::digMotorBackward(){
    motor.write(0);
}

void digMovement::digMotorStop(){
    motor.write(90);
}


// Deposit motor movement, will write to the motor, "180" for forward, "0" for backward, "90" for stop
void depositMovement::depositMotorForward(){
    motor.write(180);
}

void depositMovement::depositMotorBackward(){
    motor.write(0);
}

void depositMovement::depositMotorStop(){
    motor.write(90);
}


// Drive motor movement, will write to the motor
// Haven't decided where input will be taken from yet, once we get the info from what serial and data from that we will be receiving we can decide
// on how to implement the input, from the RPi which will take input from a controller
void driveMotorMovement::driveStraight(uint8_t speed){
    motor1.write(speed);
    motor2.write(speed);
}

// Haven't made the formula for the medTurn yet, but we will need to make a formula for the medTurn
void driveMotorMovement::driveMedLeft(uint8_t speed){
    motor1.write(speed);
    motor2.write(medTurn);
}

// Hard left turn, will write to the left motors to 90 "stop" and the right motor to the speed
void driveMotorMovement::driveHardLeft(uint8_t speed){
    motor1.write(speed);
    motor2.write(90);
}

// Haven't made the formula for the medTurn yet, but we will need to make a formula for the medTurn
void driveMotorMovement::driveMedRight(uint8_t speed){
    motor1.write(medTurn);
    motor2.write(speed);
}

// Hard right turn, will write to the right motors to 90 "stop" and the left motor to the speed
void driveMotorMovement::driveHardRight(uint8_t speed){
    motor1.write(90);
    motor2.write(speed);
}