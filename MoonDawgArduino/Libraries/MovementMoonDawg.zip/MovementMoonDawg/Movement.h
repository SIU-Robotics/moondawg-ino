// Cameron Schwartzberg
// 2/18/2024, 7:37 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#ifndef Movement_h
#define Movement_h

#include <stdint.h>
#include "Setup.h"

// Class for the rumble motor movement
// Accesses the protected "Servo motor" from the rumbleSetup class
class rumbleMovement : protected rumbleSetup {
public:
    void rumbleMotorForward();
    void rumbleMotorBackward();
    void rumbleMotorStop();
};

// Class for the dig motor movement
// Accesses the protected "Servo motor" and "(insert Actuator)" from the digSetup class
class digMovement : protected digSetup {
public:
    void digMotorForward();
    void digMotorBackward();
    void digMotorStop();
    void digActuatorForward();
    void digActuatorBackward();
    void digActuatorStop();
};

// Class for the deposit motor movement
// Accesses the protected "Servo motor" from the depositSetup class
class depositMovement : protected depositSetup {
public:
    void depositMotorForward();
    void depositMotorBackward();
    void depositMotorStop();
};

// Class for the drive motor movement
// Accesses the protected "Servo motor1" and "Servo motor2" from the driveMotorSetup class
// Uses the "uint8_t" data type for the speed of the motors, which is an 8-bit unsigned integer. From the "stdint.h" library
class driveMotorMovement : protected driveMotorSetup {
private:
    float medTurn = 0; // Equation for one side going slower than other
public:
    void driveStraight(uint8_t speed);
    void driveMedLeft(uint8_t speed);
    void driveHardLeft(uint8_t speed);
    void driveMedRight(uint8_t speed);
    void driveHardRight(uint8_t speed);
};


#endif //Movement_h
