// Cameron Schwartzberg
// 2/18/2024, 7:37 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#ifndef Movement_h
#define Movement_h

#include <stdint.h>
#include "Setup.h"
#include "PinDefinitions.h"
#include <Servo.h>

// Class for the rumble motor movement
// Accesses the protected "Servo motor" from the rumbleSetup class
class rumbleMovement : protected rumbleSetup {
public:
    rumbleMovement(uint8_t rumblePin) : rumbleSetup(rumblePin){
        motor.write(90);
    }
    void rumbleMotorForward();
    void rumbleMotorBackward();
    void rumbleMotorStop();
};

// Class for the dig motor movement
// Accesses the protected "Servo motor" and "(insert Actuator)" from the digSetup class
class digMovement : protected digSetup {
public:
    digMovement(uint8_t diggingPin, uint8_t actuatorDigPin) : digSetup(diggingPin, actuatorDigPin){
        motor.write(90);
    }
    void digMotorForward();
    void digMotorBackward();
    void digMotorStop();
    void digActuatorForward();
    void digActuatorBackward();
    void digActuatorStop();
};

// Class for the deposit motor movement
// Accesses the protected "Servo motor" from the depositSetup class
class depositMovement : protected depositSetup {
public:
    depositMovement(uint8_t depositPin) : depositSetup(depositPin){
        motor.write(90);
    }
    void depositMotorForward();
    void depositMotorBackward();
    void depositMotorStop();
};

// Class for the drive motor movement
// Accesses the protected "Servo motor1" and "Servo motor2" from the driveMotorSetup class
// Uses the "uint8_t" data type for the speed of the motors, which is an 8-bit unsigned integer. From the "stdint.h" library
class driveMotorMovement : protected driveSetup {
private:
    float medTurn = 0; // Equation for one side going slower than other
public:
    driveMotorMovement(uint8_t leftPin, uint8_t rightPin, uint8_t actuatorTurnPin) : driveSetup(leftPin, rightPin, actuatorTurnPin){
        motor1.write(90);
        motor2.write(90);
    }
    void driveStraight(uint8_t speed);
    void driveMedLeft(uint8_t speed);
    void driveHardLeft(uint8_t speed);
    void driveMedRight(uint8_t speed);
    void driveHardRight(uint8_t speed);
};


#endif //Movement_h
