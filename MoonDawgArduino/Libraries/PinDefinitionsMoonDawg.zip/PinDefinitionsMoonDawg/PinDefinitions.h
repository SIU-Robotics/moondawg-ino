// Cameron Schwartzberg
// 2/18/2024, 7:07 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#ifndef PinDefinitions_h
#define PinDefinitions_h

// Defining the pins for motor controllers
// These pins need to be updated to the correct pins
#define LEFT_MOTOR 1        // This is the pin for the left motor controllers
#define RIGHT_MOTOR 2       // This is the pin for the right motor controllers
#define TURNING_ACTUATOR 3

#define DIGGING_MOTOR 5
#define DIGGING_ACTUATOR 6

#define DEPOSIT_MOTOR 7

#define RUMBLE_MOTOR 8


#endif //PinDefinitions_h
