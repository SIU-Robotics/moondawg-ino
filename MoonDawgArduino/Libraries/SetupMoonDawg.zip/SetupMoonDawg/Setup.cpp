// Cameron Schwartzberg
// 2/18/2024, 7:30 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#include "Setup.h"

// Setup for the rumble motor, will write to "90" stop
rumbleSetup::rumbleSetup(uint8_t rumblePin){
    motor.attach(rumblePin);
    //motor.write(90);
}

// Setup for the deposit motor, will write to "90" stop
depositSetup::depositSetup(uint8_t depositPin){
    motor.attach(depositPin);
    //motor.write(90);
}

// Setup for the dig motor, will write to "90" stop
// Setup for the dig actuator, not yet implemented
digSetup::digSetup(uint8_t diggerPin, uint8_t actuatorDigPin){
    motor.attach(diggerPin);
    //motor.write(90);
}



// Setup for the drive motor, will write to "90" stop
driveSetup::driveSetup(uint8_t leftPin, uint8_t rightPin, uint8_t actuatorTurnPin){
    motor1.attach(leftPin);
    motor2.attach(rightPin);
    //Set all motors to stop in setup
    //motor1.write(90);
    //motor2.write(90);
}

