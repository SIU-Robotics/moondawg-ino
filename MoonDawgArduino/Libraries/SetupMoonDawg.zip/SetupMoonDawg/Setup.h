// Cameron Schwartzberg
// 2/18/2024, 7:30 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#ifndef Setup_h
#define Setup_h

#include <Servo.h>


// Class for the rumble motor setup
// Protecting the "Servo motor" so that it can't be accessed outside of the class
class rumbleSetup {
protected:
    Servo motor;
public:
    void rumbleMotorSetup(int rumblePin);
};

// Class for the deposit motor setup
// Protecting the "Servo motor" so that it can't be accessed outside of the class
class depositSetup {
protected:
    Servo motor;
public:
    void depositMotorSetup(int depositPin);
};

// Class for the dig motor setup
// Protecting the "Servo motor" and "(insert actuator)" so that it can't be accessed outside of the class
class digSetup {
protected:
    Servo motor;

public:
    void digMotorSetup(int diggerPin);
    void digActuatorSetup(int actuatorPin);
};

// Class for the drive motor setup
// Protecting the "Servo motor1" and "Servo motor2" so that it can't be accessed outside of the class
class driveMotorSetup{
protected:
    Servo motor1;
    Servo motor2;
public:
    void driveSetup(int leftPin, int rightPin);
};

#endif //Setup_h
