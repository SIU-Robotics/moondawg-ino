// Cameron Schwartzberg
// 2/18/2024, 7:30 PM
// 240216-212839-uno
// (Description)
// (Contributors)

#ifndef Setup_h
#define Setup_h

#include <Servo.h>


// Class for the rumble motor setup
// Protecting the "Servo motor" so that it can't be accessed outside of the class
class rumbleSetup {
protected:
    Servo motor;
public:
    rumbleSetup(uint8_t rumblePin);
};

// Class for the dig motor setup
// Protecting the "Servo motor" and "(insert actuator)" so that it can't be accessed outside of the class
class digSetup {
protected:
    Servo motor;

public:
    digSetup(uint8_t diggingPin, uint8_t actuatorDigPin);
};

// Class for the deposit motor setup
// Protecting the "Servo motor" so that it can't be accessed outside of the class
class depositSetup {
protected:
    Servo motor;
public:
    depositSetup(uint8_t depositPin);
};

// Class for the drive motor setup
// Protecting the "Servo motor1" and "Servo motor2" so that it can't be accessed outside of the class
class driveSetup{
protected:
    Servo motor1;
    Servo motor2;
    
public:
    driveSetup(uint8_t leftPin, uint8_t rightPin, uint8_t actuatorTurnPin);
};

#endif //Setup_h
